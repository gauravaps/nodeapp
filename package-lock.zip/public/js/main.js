const submitBtn=document.getElementById('submitbtn');
const cityName=document.getElementById('cityName')
const city_name=document.getElementById('city_name')
const temp_realval=document.getElementById('temp_realval')
const temp_status=document.getElementById('temp_status')
const datahide=document.querySelector('.middle_layer')
const day=document.getElementById("day")
const date=document.getElementById("today_date")

const getinfo= async(event)=>{
    //alert("hiiii")
    event.preventDefault();
    let cityval=cityName.value;


    if(cityval ===""){
        city_name.innerText="please write the name before search";
        datahide.classList.add('data_hide')

    } 
    else{
        try{
        
    let url=`https://api.openweathermap.org/data/2.5/weather?q=${cityval}&units=metric&appid=ec56a02061c4df78e35c2f4b17d5d780`
    const response=await fetch(url)
    const data=await response.json();
    console.log(data)
    const arrdata=[data]
    city_name.innerText=`${arrdata[0].name}, ${arrdata[0].sys.country}`
    temp_realval.innerText=arrdata[0].main.temp;
    temp_status.innerText=arrdata[0].weather[0].main;
    const temstatus=arrdata[0].weather[0].main;
    //condtion to check status cloudy or sunny
    if(temstatus==="Clear"){
        temp_status.innerHTML=
        "<i class='fas fa-sun' style='color:#eccc68;'></i>";
    }
    else if(temstatus==="Cloud"){
        temp_status.innerHTML=
        "<i class='fas fa-cloud' style='color:f1f2f6;'></i>";
    }
    else if(temstatus==="Rain"){
        temp_status.innerHTML=
        "<i class='fas fa-cloud-rain' style='color:#a4b0be;'></i>";
    }
    else{
        temp_status.innerHTML="<i class='fas fa-cloud' style='color:#f1f2f6;'></i>";
        }
        datahide.classList.remove('data_hide')
        }catch{
            city_name.innerText=`please enter city name properly`
            datahide.classList.add('data_hide')
        }

    }
}
const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

        const d = new Date();
        let days = weekday[d.getDay()];
        let date1=d.getDate()
        
    
        day.innerText=`${days}`
        date.innerText=`${date1}`
 
submitBtn.addEventListener('click',getinfo); 