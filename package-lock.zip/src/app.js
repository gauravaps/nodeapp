const express=require("express");
const path=require("path");
const app=express();
const hbs=require("hbs");

//public static path
const publictaticpath=path.join(__dirname, "../public")
const partialpath=path.join(__dirname,"./views/partial")

app.set('view engine','hbs');
hbs.registerPartials(partialpath);
app.use(express.static(publictaticpath)) 


//routing
app.get("",(req,res)=>{
    res.render('index.hbs')     

})
app.get("/about",(req,res)=>{
    res.render('about')
})
app.get("/weather",(req,res)=>{
    res.render('weather')  

})

app.get("/demo",(req,res)=>{ 
    res.render('demo') 
})    
app.get("*",(req,res)=>{
    res.render('404')
})


app.listen(3000); 



// function   